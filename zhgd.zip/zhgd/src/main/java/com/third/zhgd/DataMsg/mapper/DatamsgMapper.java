package com.third.zhgd.DataMsg.mapper;

import com.third.zhgd.DataMsg.entity.Datamsg;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Csk
 * @since 2024-05-01
 */
public interface DatamsgMapper extends BaseMapper<Datamsg> {

}
