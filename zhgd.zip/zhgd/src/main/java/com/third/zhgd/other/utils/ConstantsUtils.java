package com.third.zhgd.other.utils;

public class ConstantsUtils {
    public static final int GL_DEL =0;
    public static final int GL_NORMAL =1;
}
