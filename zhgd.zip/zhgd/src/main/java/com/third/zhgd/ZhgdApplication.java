package com.third.zhgd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZhgdApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZhgdApplication.class, args);
    }

}
