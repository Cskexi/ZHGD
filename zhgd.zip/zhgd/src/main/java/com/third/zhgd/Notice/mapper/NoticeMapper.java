package com.third.zhgd.Notice.mapper;

import com.third.zhgd.Notice.entity.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Csk
 * @since 2024-05-21
 */
public interface NoticeMapper extends BaseMapper<Notice> {

}
