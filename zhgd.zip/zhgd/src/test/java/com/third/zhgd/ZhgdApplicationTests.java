package com.third.zhgd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZhgdApplicationTests {

    @Test
    void contextLoads() {
    }

}
